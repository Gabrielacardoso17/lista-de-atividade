f = float (input ('digite o valor de f: '))
c = 5 *(f-32/9)
print(c)