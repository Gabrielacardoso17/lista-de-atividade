n1 = int (input ('informe um número '))
n2 = int (input ('informe outro número '))
resul= n1 + n2
print (resul)