valor_por_hora = float (input('quanto voce ganha por hora '))
num_de_h_trab = float (input('numero de horas trabalhadas no mes' ))
salario_do_mes = valor_por_hora * num_de_h_trab
print( salario_do_mes)