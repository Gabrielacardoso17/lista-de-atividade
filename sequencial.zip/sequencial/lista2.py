numero=10
print ("O numero informado foi",(numero))