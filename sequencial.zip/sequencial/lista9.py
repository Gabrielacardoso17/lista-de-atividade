altura = float (input('informe sua altura '))
peso_ideal = (72.7*altura) -58
print(peso_ideal)