altura = float (input("digite a altura do quadrado "))
largura = float (input("digite a largura do quadrado "))
a = altura * largura
print('o dobro da area e:', a*2)