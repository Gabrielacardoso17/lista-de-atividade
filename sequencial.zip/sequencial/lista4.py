raio_inf = float (input('digite o raio da circunferencia:'))
PI = 3.14
area_circu = PI + raio_inf**2 
print (area_circu)