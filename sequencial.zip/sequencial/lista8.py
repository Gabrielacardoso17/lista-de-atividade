c = float (input('digite o valor de celsius '))
f = c * 1.8 + 32
print(f)