numero= int (input('digite um numero '))
if ( numero%2) == 0 :
    print('par')
else :
    print('impar')    