char = input ('digite uma letra ')
if char == 'a' or char =='e' or char == 'i' or char == 'o' or char =='u' :
    print('vogal')
else :
    print ('cosoante')    