n1 = 20
n2 = 49
n3 = 9
if n1 > n2 and n2 > n3 :
    print(n1)
elif n1 < n2 and n2 > n3 :
    print(n2)
elif n1 < n2 and n2 < n3 :
    print(n3)        