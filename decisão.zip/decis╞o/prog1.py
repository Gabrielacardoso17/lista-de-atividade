genero = input ('Qual seu genero: ')
if genero == 'f' :
    print ('feminino')
elif genero == 'm' :
    print ('masculino')
else :
    print ('sexo invalido')        